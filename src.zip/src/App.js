// ============================================================
// LACA TV — Complete React Application
// Pages: Home, Video Player, Admin Panel
// Features: Live Scores Ticker (simulated + API-Football ready),
//           League Filter, Admin Upload/Delete, Video Management
// Admin password: lacatv2026
// ============================================================

import { useState, useEffect, useRef, createContext, useContext } from "react";

// ─── GOOGLE FONTS ─────────────────────────────────────────────
const fontLink = document.createElement("link");
fontLink.rel = "stylesheet";
fontLink.href = "https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&display=swap";
document.head.appendChild(fontLink);

// ─── GLOBAL STYLES ────────────────────────────────────────────
const GlobalStyle = () => (
  <style>{`
    *{box-sizing:border-box;margin:0;padding:0}
    :root{
      --green:#1a7a3c;--green-dark:#0f4f25;--green-light:#23a052;
      --gold:#f5c518;--bg:#0d1117;--surface:#161b22;
      --surface2:#21262d;--border:#30363d;--text:#e6edf3;--muted:#8b949e;
      --red:#e74c3c;
    }
    body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;font-size:14px}
    button{cursor:pointer;font-family:'DM Sans',sans-serif}
    input,select,textarea{font-family:'DM Sans',sans-serif}
    ::-webkit-scrollbar{width:6px;height:6px}
    ::-webkit-scrollbar-track{background:var(--bg)}
    ::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
    @keyframes tickerScroll{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
    @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
    .fade-in{animation:fadeIn .3s ease forwards}
  `}</style>
);

// ─── MOCK DATA ────────────────────────────────────────────────
const MOCK_VIDEOS = [
  { id:1, title:"Real Madrid 4-3 Man City — All Goals & Highlights", league:"Champions League", leagueFlag:"🏆", duration:"14:22", views:128000, uploadedAt:"2026-03-31T10:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Incredible Champions League semi-final with 7 goals! Real Madrid edge out Man City in a thriller at the Bernabeu. Vinicius Jr. with a stunning brace.", tags:["Real Madrid","Man City","Champions League"], featured:true, isNew:true, bgGrad:"135deg,#0f4f25,#1a7a3c" },
  { id:2, title:"Arsenal 2-1 Tottenham — North London Derby Highlights", league:"Premier League", leagueFlag:"🏴󠁧󠁢󠁥󠁮󠁧󠁿", duration:"8:24", views:84000, uploadedAt:"2026-03-31T08:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Arsenal claim derby bragging rights with a late winner from Saka. Controversial VAR moment in the second half changes the game.", tags:["Arsenal","Tottenham","Premier League"], featured:false, isNew:true, bgGrad:"135deg,#1a237e,#283593" },
  { id:3, title:"Barcelona vs Atletico Madrid — Extended Highlights", league:"La Liga", leagueFlag:"🇪🇸", duration:"10:05", views:56000, uploadedAt:"2026-03-30T20:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"El Clasico del Atletico ends 1-1. Lewandowski equaliser cancelled out by Griezmann wonder goal from 35 yards.", tags:["Barcelona","Atletico Madrid","La Liga"], featured:false, isNew:false, bgGrad:"135deg,#b71c1c,#c62828" },
  { id:4, title:"Bayern Munich 3-2 Dortmund — Der Klassiker Full Highlights", league:"Bundesliga", leagueFlag:"🇩🇪", duration:"11:05", views:72000, uploadedAt:"2026-03-30T18:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Bayern snatch a late winner to claim all three points. Kane hat-trick leads the comeback from 2-0 down.", tags:["Bayern Munich","Dortmund","Bundesliga"], featured:false, isNew:true, bgGrad:"135deg,#1b5e20,#2e7d32" },
  { id:5, title:"Nigeria vs South Africa — AFCON 2025 Highlights", league:"AFCON", leagueFlag:"🌍", duration:"6:12", views:210000, uploadedAt:"2026-03-29T16:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Super Eagles dominate to reach the AFCON quarter finals. Osimhen hat-trick lights up the tournament in front of 80,000 fans.", tags:["Nigeria","South Africa","AFCON","Super Eagles"], featured:false, isNew:false, bgGrad:"135deg,#004d40,#00695c" },
  { id:6, title:"Inter Milan 3-1 AC Milan — Derby Della Madonnina", league:"Serie A", leagueFlag:"🇮🇹", duration:"7:33", views:143000, uploadedAt:"2026-03-29T15:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Inter Milan thrash city rivals in a dominant display. Lautaro Martinez with a brace in front of a sold-out San Siro.", tags:["Inter Milan","AC Milan","Serie A"], featured:false, isNew:false, bgGrad:"135deg,#0d47a1,#1565c0" },
  { id:7, title:"Enyimba FC vs Rivers United — NPFL Matchday 22", league:"NPFL", leagueFlag:"🇳🇬", duration:"5:58", views:18000, uploadedAt:"2026-03-31T12:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Enyimba FC claim a crucial three points at home in the NPFL title race. Late goal seals a hard-fought win.", tags:["Enyimba","Rivers United","NPFL","Nigeria"], featured:false, isNew:true, bgGrad:"135deg,#33691e,#558b2f" },
  { id:8, title:"Manchester United 0-2 Liverpool — Premier League Highlights", league:"Premier League", leagueFlag:"🏴󠁧󠁢󠁥󠁮󠁧󠁿", duration:"10:20", views:389000, uploadedAt:"2026-03-28T17:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Liverpool ease past United at Old Trafford. Salah and Nunez on target as the Reds extend their lead at the top.", tags:["Manchester United","Liverpool","Premier League"], featured:false, isNew:false, bgGrad:"135deg,#880e4f,#ad1457" },
  { id:9, title:"PSG 2-0 Juventus — UCL Quarter Final Highlights", league:"Champions League", leagueFlag:"🏆", duration:"9:47", views:95000, uploadedAt:"2026-03-28T21:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"PSG control the tie with a professional display at Parc des Princes. Mbappé and Dembélé on target.", tags:["PSG","Juventus","Champions League"], featured:false, isNew:false, bgGrad:"135deg,#4a148c,#6a1b9a" },
  { id:10, title:"Kano Pillars vs Plateau United — NPFL Highlights", league:"NPFL", leagueFlag:"🇳🇬", duration:"5:20", views:12000, uploadedAt:"2026-03-30T14:00:00Z", videoUrl:"https://www.w3schools.com/html/mov_bbb.mp4", description:"Kano Pillars bounce back with a vital home win. Exciting end-to-end football in the NPFL midseason clash.", tags:["Kano Pillars","Plateau United","NPFL"], featured:false, isNew:false, bgGrad:"135deg,#e65100,#bf360c" },
];

const LEAGUES = ["All","Premier League","La Liga","Champions League","Bundesliga","Serie A","AFCON","NPFL","Ligue 1"];

const INIT_SCORES = [
  { id:1, league:"EPL",      home:"Arsenal",    away:"Tottenham",  score:"2-1", minute:90, live:false },
  { id:2, league:"La Liga",  home:"Barcelona",  away:"Atletico",   score:"1-1", minute:67, live:true  },
  { id:3, league:"UCL",      home:"Real Madrid",away:"Man City",   score:"4-3", minute:90, live:false },
  { id:4, league:"Bundesliga",home:"Bayern",    away:"Dortmund",   score:"3-2", minute:90, live:false },
  { id:5, league:"Serie A",  home:"Inter",      away:"AC Milan",   score:"3-1", minute:90, live:false },
  { id:6, league:"Ligue 1",  home:"PSG",        away:"Marseille",  score:"2-0", minute:78, live:true  },
  { id:7, league:"NPFL",     home:"Enyimba",    away:"Rivers Utd", score:"1-0", minute:90, live:false },
  { id:8, league:"EPL",      home:"Chelsea",    away:"Man City",   score:"0-2", minute:45, live:true  },
  { id:9, league:"UCL",      home:"PSG",        away:"Juventus",   score:"1-0", minute:90, live:false },
  { id:10,league:"La Liga",  home:"Real Madrid",away:"Sevilla",    score:"3-0", minute:90, live:false },
];

// ─── CONTEXT ──────────────────────────────────────────────────
const AppCtx = createContext(null);
const useApp = () => useContext(AppCtx);

// ─── HELPERS ──────────────────────────────────────────────────
const fmtViews = n => n >= 1000000 ? (n/1e6).toFixed(1)+"M" : n >= 1000 ? Math.round(n/1000)+"K" : String(n);
const timeAgo  = iso => {
  const s = (Date.now() - new Date(iso)) / 1000;
  if (s < 3600)  return Math.round(s/60)+"m ago";
  if (s < 86400) return Math.round(s/3600)+"h ago";
  return Math.round(s/86400)+"d ago";
};

// ─── SCORES TICKER ────────────────────────────────────────────
function ScoresTicker({ scores }) {
  const doubled = [...scores, ...scores];
  return (
    <div style={{ background:"var(--surface)", borderBottom:"1px solid var(--border)", height:38, display:"flex", alignItems:"center", overflow:"hidden" }}>
      <div style={{ background:"var(--green)", color:"#fff", fontWeight:600, fontSize:11, padding:"0 12px", height:"100%", display:"flex", alignItems:"center", whiteSpace:"nowrap", textTransform:"uppercase", letterSpacing:1, flexShrink:0 }}>
        🔴 Live Scores
      </div>
      <div style={{ overflow:"hidden", flex:1, display:"flex", alignItems:"center" }}>
        <div style={{ display:"flex", alignItems:"center", animation:"tickerScroll 50s linear infinite", whiteSpace:"nowrap" }}>
          {doubled.map((s,i) => (
            <div key={i} style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"0 20px", borderRight:"1px solid var(--border)", height:38, fontSize:12 }}>
              <span style={{ color:"var(--gold)", fontSize:10, fontWeight:600, textTransform:"uppercase" }}>{s.league}</span>
              <span style={{ color:"var(--text)", fontWeight:500 }}>{s.home}</span>
              <span style={{ color:"var(--gold)", fontWeight:700, fontSize:14, minWidth:32, textAlign:"center" }}>{s.score}</span>
              <span style={{ color:"var(--text)", fontWeight:500 }}>{s.away}</span>
              {s.live && <span style={{ width:6, height:6, borderRadius:"50%", background:"var(--red)", animation:"pulse 1s infinite", display:"inline-block" }} />}
              <span style={{ color:"var(--muted)", fontSize:11 }}>{s.live ? s.minute+"'" : "FT"}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── HEADER ───────────────────────────────────────────────────
function Header({ onAdmin, search, setSearch }) {
  return (
    <div style={{ background:"var(--green-dark)", borderBottom:"2px solid var(--green)", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 20px", height:56, position:"sticky", top:0, zIndex:100, gap:12 }}>
      <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:28, color:"var(--gold)", letterSpacing:2, display:"flex", alignItems:"center", gap:6, flexShrink:0 }}>
        ⚽ LACA TV
        <span style={{ background:"var(--gold)", color:"var(--green-dark)", fontSize:10, fontFamily:"'DM Sans',sans-serif", fontWeight:600, padding:"2px 6px", borderRadius:4, letterSpacing:1 }}>LIVE</span>
      </div>
      <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:20, padding:"6px 14px", display:"flex", alignItems:"center", gap:8, flex:1, maxWidth:300 }}>
        <span style={{ color:"var(--muted)" }}>🔍</span>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search highlights, teams, leagues..." style={{ background:"transparent", border:"none", outline:"none", color:"var(--text)", width:"100%", fontSize:13 }} />
        {search && <span onClick={()=>setSearch("")} style={{ color:"var(--muted)", cursor:"pointer", fontSize:16 }}>×</span>}
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:12 }}>
        <button onClick={onAdmin} style={{ background:"var(--surface2)", color:"var(--muted)", border:"1px solid var(--border)", borderRadius:20, padding:"6px 16px", fontSize:13, fontWeight:500 }}>🔐 Admin</button>
        <div style={{ width:34, height:34, borderRadius:"50%", background:"var(--gold)", color:"var(--green-dark)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:600, fontSize:14, flexShrink:0 }}>LA</div>
      </div>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────
function Sidebar({ activeLeague, setActiveLeague, activeNav, setActiveNav }) {
  const navItems = [
    { id:"home",     icon:"🏠", label:"Home"     },
    { id:"trending", icon:"🔥", label:"Trending" },
    { id:"recent",   icon:"🕐", label:"Recent"   },
    { id:"saved",    icon:"⭐", label:"Saved"    },
  ];
  const leagueItems = [
    { id:"Premier League",   icon:"🏴󠁧󠁢󠁥󠁮󠁧󠁿" },
    { id:"La Liga",          icon:"🇪🇸" },
    { id:"Bundesliga",       icon:"🇩🇪" },
    { id:"Serie A",          icon:"🇮🇹" },
    { id:"NPFL",             icon:"🇳🇬" },
    { id:"Champions League", icon:"🏆" },
    { id:"AFCON",            icon:"🌍" },
    { id:"Ligue 1",          icon:"🇫🇷" },
  ];
  const row = (active) => ({ display:"flex", alignItems:"center", gap:12, padding:"9px 18px", color: active?"var(--text)":"var(--muted)", cursor:"pointer", fontSize:13, transition:"all .15s", background: active?"var(--surface2)":"transparent", borderLeft: active?"3px solid var(--green-light)":"3px solid transparent" });
  return (
    <div style={{ width:200, background:"var(--surface)", borderRight:"1px solid var(--border)", padding:"16px 0", flexShrink:0 }}>
      {navItems.map(n => (
        <div key={n.id} style={row(activeNav===n.id)} onClick={()=>{ setActiveNav(n.id); setActiveLeague("All"); }}>
          <span style={{ fontSize:16, width:20, textAlign:"center" }}>{n.icon}</span>{n.label}
        </div>
      ))}
      <div style={{ padding:"12px 18px 6px", color:"var(--muted)", fontSize:11, fontWeight:600, textTransform:"uppercase", letterSpacing:1, marginTop:8 }}>Leagues</div>
      {leagueItems.map(l => (
        <div key={l.id} style={row(activeLeague===l.id)} onClick={()=>{ setActiveLeague(l.id); setActiveNav(null); }}>
          <span style={{ fontSize:16, width:20, textAlign:"center" }}>{l.icon}</span>{l.id}
        </div>
      ))}
      <div style={{ padding:"12px 18px 6px", color:"var(--muted)", fontSize:11, fontWeight:600, textTransform:"uppercase", letterSpacing:1, marginTop:8 }}>More</div>
      <div style={row(false)}><span style={{ fontSize:16, width:20, textAlign:"center" }}>⚙️</span>Settings</div>
    </div>
  );
}

// ─── VIDEO CARD ───────────────────────────────────────────────
function VideoCard({ video, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <div className="fade-in" onClick={()=>onClick(video)} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ cursor:"pointer", transform: hov?"translateY(-3px)":"none", transition:"transform .15s" }}>
      <div style={{ position:"relative", borderRadius:10, overflow:"hidden", aspectRatio:"16/9", background:"var(--surface2)" }}>
        <div style={{ width:"100%", height:"100%", background:`linear-gradient(${video.bgGrad})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:36 }}>⚽</div>
        {video.isNew
          ? <div style={{ position:"absolute", top:8, left:8, background:"var(--green-light)", color:"#fff", fontSize:10, padding:"3px 8px", borderRadius:4, fontWeight:600 }}>NEW</div>
          : video.duration && <div style={{ position:"absolute", bottom:6, right:8, background:"rgba(0,0,0,.8)", color:"#fff", fontSize:11, padding:"2px 6px", borderRadius:4, fontWeight:500 }}>{video.duration}</div>
        }
        {hov && (
          <div style={{ position:"absolute", inset:0, background:"rgba(0,0,0,.4)", display:"flex", alignItems:"center", justifyContent:"center" }}>
            <div style={{ width:48, height:48, background:"rgba(255,255,255,.9)", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>▶</div>
          </div>
        )}
      </div>
      <div style={{ padding:"10px 4px 4px" }}>
        <div style={{ fontSize:13, fontWeight:500, lineHeight:1.4, marginBottom:4, color:"var(--text)", display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{video.title}</div>
        <div style={{ fontSize:12, color:"var(--muted)", display:"flex", gap:8, alignItems:"center", flexWrap:"wrap" }}>
          <span style={{ background:"var(--surface2)", border:"1px solid var(--border)", color:"var(--muted)", fontSize:10, padding:"2px 8px", borderRadius:10 }}>{video.league}</span>
          <span>{fmtViews(video.views)} views</span>
          <span>•</span>
          <span>{timeAgo(video.uploadedAt)}</span>
        </div>
      </div>
    </div>
  );
}

// ─── HERO BANNER ──────────────────────────────────────────────
function Hero({ video, onClick }) {
  if (!video) return null;
  return (
    <div onClick={()=>onClick(video)} style={{ position:"relative", borderRadius:14, overflow:"hidden", marginBottom:24, aspectRatio:"16/7", cursor:"pointer" }}>
      <div style={{ width:"100%", height:"100%", background:`linear-gradient(${video.bgGrad})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:80, opacity:.3 }}>⚽</div>
      <div style={{ position:"absolute", inset:0, background:"linear-gradient(to right,rgba(0,0,0,.85) 0%,rgba(0,0,0,.2) 60%,transparent 100%)", display:"flex", alignItems:"center", padding:32 }}>
        <div style={{ maxWidth:480 }}>
          <div style={{ color:"var(--gold)", fontSize:12, fontWeight:600, textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>⚡ {video.league} — Featured</div>
          <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:34, letterSpacing:1, lineHeight:1.1, marginBottom:10, color:"#fff" }}>{video.title}</div>
          <div style={{ color:"rgba(255,255,255,.6)", fontSize:13, marginBottom:18 }}>{fmtViews(video.views)} views &nbsp;•&nbsp; {timeAgo(video.uploadedAt)} &nbsp;•&nbsp; {video.duration}</div>
          <button style={{ background:"var(--gold)", color:"var(--green-dark)", border:"none", borderRadius:24, padding:"10px 24px", fontWeight:600, fontSize:14, display:"flex", alignItems:"center", gap:8 }}>▶ Watch Now</button>
        </div>
      </div>
    </div>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────
function HomePage() {
  const { videos, navigate } = useApp();
  const [league, setLeague]   = useState("All");
  const [nav, setNav]         = useState("home");
  const [search, setSearch]   = useState("");
  const [scores, setScores]   = useState(INIT_SCORES);

  // Simulated live score tick — replace with real API call below
  useEffect(() => {
    const iv = setInterval(() => {
      setScores(prev => prev.map(s => {
        if (!s.live) return s;
        const m = Math.min(90, s.minute + 1);
        let sc = s.score;
        if (Math.random() < 0.07) {
          const [h,a] = s.score.split("-").map(Number);
          sc = Math.random() < 0.5 ? `${h+1}-${a}` : `${h}-${a+1}`;
        }
        return { ...s, minute:m, score:sc, live: m < 90 };
      }));
    }, 8000);
    return () => clearInterval(iv);
  }, []);

  // ── API-Football integration ──────────────────────────────
  // To enable real scores:
  // 1. Get a free key at https://dashboard.api-football.com
  // 2. Replace "YOUR_KEY_HERE" below and uncomment this block
  //
  // useEffect(() => {
  //   const KEY = "YOUR_KEY_HERE";
  //   const load = async () => {
  //     try {
  //       const today = new Date().toISOString().split("T")[0];
  //       const r = await fetch(
  //         `https://v3.football.api-sports.io/fixtures?date=${today}`,
  //         { headers: { "x-apisports-key": KEY } }
  //       );
  //       const d = await r.json();
  //       const live = ["1H","2H","HT","ET","P","INT"];
  //       setScores(d.response.slice(0,20).map(f => ({
  //         id:      f.fixture.id,
  //         league:  f.league.name.slice(0,12),
  //         home:    f.teams.home.name.split(" ").slice(-1)[0],
  //         away:    f.teams.away.name.split(" ").slice(-1)[0],
  //         score:  `${f.goals.home ?? 0}-${f.goals.away ?? 0}`,
  //         minute:  f.fixture.status.elapsed ?? 90,
  //         live:    live.includes(f.fixture.status.short),
  //       })));
  //     } catch(e) { console.warn("API-Football error, using mock scores"); }
  //   };
  //   load();
  //   const iv = setInterval(load, 60000);
  //   return () => clearInterval(iv);
  // }, []);

  const filtered = videos
    .filter(v => {
      const ml = league === "All" || v.league === league;
      const ms = !search || v.title.toLowerCase().includes(search.toLowerCase()) || v.tags?.join(" ").toLowerCase().includes(search.toLowerCase());
      if (nav === "trending") return ml && ms && v.views > 50000;
      return ml && ms;
    })
    .sort((a,b) => nav==="trending" ? b.views - a.views : new Date(b.uploadedAt) - new Date(a.uploadedAt));

  const featured = videos.find(v => v.featured) || videos[0];

  const SectionTitle = ({ children, sub }) => (
    <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:22, letterSpacing:1, color:"var(--text)", marginBottom:14, display:"flex", alignItems:"center", gap:10 }}>
      {children}
      {sub && <span style={{ fontSize:12, fontFamily:"'DM Sans',sans-serif", color:"var(--muted)", fontWeight:400, letterSpacing:0 }}>{sub}</span>}
    </div>
  );

  return (
    <div style={{ background:"var(--bg)", minHeight:"100vh" }}>
      <GlobalStyle />
      <Header onAdmin={()=>navigate("admin")} search={search} setSearch={setSearch} />
      <ScoresTicker scores={scores} />
      <div style={{ display:"flex", minHeight:"calc(100vh - 94px)" }}>
        <Sidebar activeLeague={league} setActiveLeague={setLeague} activeNav={nav} setActiveNav={setNav} />
        <div style={{ flex:1, padding:"20px 24px", overflowY:"auto" }}>

          {/* Hero only on default home view */}
          {!search && nav==="home" && league==="All" && <Hero video={featured} onClick={v=>navigate("player",v)} />}

          {/* League filter tabs */}
          <div style={{ display:"flex", gap:8, marginBottom:18, flexWrap:"wrap" }}>
            {LEAGUES.map(l => (
              <button key={l} onClick={()=>{ setLeague(l); setNav(null); }}
                style={{ padding:"6px 16px", borderRadius:20, border:"1px solid var(--border)", background: league===l?"var(--green-light)":"transparent", color: league===l?"#fff":"var(--muted)", fontSize:12, transition:".15s" }}>
                {l}
              </button>
            ))}
          </div>

          {search
            ? <SectionTitle sub={`${filtered.length} result${filtered.length!==1?"s":""}`}>🔍 "{search}"</SectionTitle>
            : <SectionTitle sub="updated every hour">{nav==="trending" ? "🔥 Trending Today" : league!=="All" ? `${league} Highlights` : "🎬 Latest Highlights"}</SectionTitle>
          }

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:18, marginBottom:30 }}>
            {filtered.map(v => <VideoCard key={v.id} video={v} onClick={v=>navigate("player",v)} />)}
          </div>

          {filtered.length === 0 && (
            <div style={{ textAlign:"center", padding:"60px 20px", color:"var(--muted)" }}>
              <div style={{ fontSize:48, marginBottom:12 }}>⚽</div>
              <div style={{ fontSize:16 }}>No highlights found</div>
              {search && <div style={{ fontSize:13, marginTop:6 }}>Try a different search term</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── VIDEO PLAYER PAGE ────────────────────────────────────────
function VideoPlayerPage({ video }) {
  const { videos, navigate } = useApp();
  const [liked, setLiked]   = useState(false);
  const [saved, setSaved]   = useState(false);
  if (!video) { navigate("home"); return null; }
  const related = videos.filter(v => v.id !== video.id).sort((a,b) => b.views - a.views).slice(0, 7);

  return (
    <div style={{ background:"var(--bg)", minHeight:"100vh" }}>
      <GlobalStyle />
      <Header onAdmin={()=>navigate("admin")} search="" setSearch={()=>{}} />
      <div style={{ display:"flex" }}>
        {/* Player + info */}
        <div style={{ flex:1, padding:24, minWidth:0 }}>
          {/* Video */}
          <div style={{ borderRadius:12, overflow:"hidden", background:"#000", marginBottom:16, aspectRatio:"16/9" }}>
            <video controls autoPlay style={{ width:"100%", height:"100%", display:"block" }} src={video.videoUrl} />
          </div>

          {/* Title row */}
          <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:26, letterSpacing:1, lineHeight:1.2, marginBottom:10, color:"var(--text)" }}>{video.title}</div>

          {/* Meta + actions */}
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:10, marginBottom:16, paddingBottom:16, borderBottom:"1px solid var(--border)" }}>
            <div style={{ fontSize:13, color:"var(--muted)", display:"flex", gap:10, alignItems:"center" }}>
              <span>{video.leagueFlag} {video.league}</span>
              <span>•</span>
              <span>{fmtViews(video.views)} views</span>
              <span>•</span>
              <span>{timeAgo(video.uploadedAt)}</span>
              <span>•</span>
              <span>{video.duration}</span>
            </div>
            <div style={{ display:"flex", gap:8 }}>
              {[
                { label: liked?"👍 Liked":"👍 Like",    act:()=>setLiked(!liked), active:liked, activeStyle:{background:"var(--green-light)",color:"#fff",borderColor:"var(--green-light)"} },
                { label: saved?"⭐ Saved":"☆ Save",      act:()=>setSaved(!saved), active:saved, activeStyle:{background:"var(--gold)",color:"var(--green-dark)",borderColor:"var(--gold)"} },
                { label: "↗ Share", act:()=>{}, active:false, activeStyle:{} },
              ].map(btn => (
                <button key={btn.label} onClick={btn.act} style={{ background:"var(--surface2)", color:"var(--muted)", border:"1px solid var(--border)", borderRadius:20, padding:"7px 16px", fontSize:13, ...(btn.active ? btn.activeStyle : {}) }}>
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div style={{ background:"var(--surface)", borderRadius:10, padding:16, border:"1px solid var(--border)", marginBottom:20 }}>
            <div style={{ fontSize:13, lineHeight:1.7, color:"var(--text)", marginBottom:10 }}>{video.description}</div>
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {video.tags?.map(t => (
                <span key={t} style={{ background:"var(--surface2)", border:"1px solid var(--border)", color:"var(--muted)", fontSize:11, padding:"3px 10px", borderRadius:10 }}>#{t}</span>
              ))}
            </div>
          </div>

          <button onClick={()=>navigate("home")} style={{ background:"var(--surface2)", color:"var(--muted)", border:"1px solid var(--border)", borderRadius:8, padding:"8px 16px", fontSize:13 }}>
            ← Back to Home
          </button>
        </div>

        {/* Related sidebar */}
        <div style={{ width:320, padding:"24px 24px 24px 0", flexShrink:0 }}>
          <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, letterSpacing:1, marginBottom:14, color:"var(--text)" }}>Up Next</div>
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            {related.map(v => (
              <div key={v.id} onClick={()=>navigate("player",v)} style={{ display:"flex", gap:10, cursor:"pointer", padding:8, borderRadius:8 }}
                onMouseEnter={e=>e.currentTarget.style.background="var(--surface)"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <div style={{ flexShrink:0, width:120, aspectRatio:"16/9", borderRadius:6, overflow:"hidden", background:`linear-gradient(${v.bgGrad})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, position:"relative" }}>
                  ⚽
                  <span style={{ position:"absolute", bottom:3, right:4, background:"rgba(0,0,0,.8)", color:"#fff", fontSize:10, padding:"1px 4px", borderRadius:3 }}>{v.duration}</span>
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:12, fontWeight:500, color:"var(--text)", lineHeight:1.4, marginBottom:4, display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{v.title}</div>
                  <div style={{ fontSize:11, color:"var(--muted)" }}>{v.league}</div>
                  <div style={{ fontSize:11, color:"var(--muted)" }}>{fmtViews(v.views)} views</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ADMIN LOGIN ──────────────────────────────────────────────
function AdminLogin({ onLogin }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  // ⚠️ Change this password before going live!
  const PASS = "lacatv2026";
  const attempt = () => {
    if (pw === PASS) onLogin();
    else { setErr("Incorrect password. Try again."); setPw(""); }
  };
  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", background:"var(--bg)" }}>
      <GlobalStyle />
      <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:16, padding:40, width:360, textAlign:"center" }}>
        <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:32, color:"var(--gold)", letterSpacing:2, marginBottom:4 }}>⚽ LACA TV</div>
        <div style={{ color:"var(--muted)", fontSize:13, marginBottom:28 }}>Admin Access Only</div>
        <div style={{ background:"var(--surface2)", borderRadius:8, padding:"10px 14px", marginBottom:12, border:"1px solid var(--border)", textAlign:"left" }}>
          <input type="password" value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&attempt()} placeholder="Enter admin password" style={{ background:"transparent", border:"none", outline:"none", color:"var(--text)", width:"100%", fontSize:14 }} autoFocus />
        </div>
        {err && <div style={{ color:"var(--red)", fontSize:12, marginBottom:10 }}>{err}</div>}
        <button onClick={attempt} style={{ background:"var(--green-light)", color:"#fff", border:"none", borderRadius:8, padding:"11px 24px", fontSize:14, fontWeight:600, width:"100%" }}>Login to Admin</button>
        <div style={{ marginTop:14, fontSize:12, color:"var(--muted)" }}>Default: <code style={{ color:"var(--gold)" }}>lacatv2026</code></div>
      </div>
    </div>
  );
}

// ─── ADMIN PANEL ──────────────────────────────────────────────
function AdminPage() {
  const { videos, addVideo, deleteVideo, navigate, adminAuth, setAdminAuth } = useApp();
  const [tab, setTab]   = useState("upload");
  const [msg, setMsg]   = useState(null);
  const [form, setForm] = useState({
    title:"", league:"Premier League", duration:"", videoUrl:"",
    description:"", tags:"", isNew:true, featured:false,
    bgGrad:"135deg,#1a7a3c,#0f4f25",
  });

  if (!adminAuth) return <AdminLogin onLogin={()=>setAdminAuth(true)} />;

  const notify = (type, text) => { setMsg({type,text}); setTimeout(()=>setMsg(null),3500); };

  const upload = () => {
    if (!form.title.trim()) return notify("err","Title is required.");
    if (!form.videoUrl.trim()) return notify("err","Video URL is required.");
    addVideo({ ...form, tags: form.tags.split(",").map(t=>t.trim()).filter(Boolean), leagueFlag:"🏆" });
    notify("ok","✅ Video published successfully!");
    setForm({ title:"", league:"Premier League", duration:"", videoUrl:"", description:"", tags:"", isNew:true, featured:false, bgGrad:"135deg,#1a7a3c,#0f4f25" });
  };

  const inp = { background:"var(--surface2)", border:"1px solid var(--border)", borderRadius:8, padding:"10px 14px", color:"var(--text)", width:"100%", fontSize:13, outline:"none" };
  const lbl = { fontSize:12, color:"var(--muted)", display:"block", marginBottom:5 };

  const grads = [
    {l:"Green",  v:"135deg,#0f4f25,#1a7a3c"}, {l:"Navy",   v:"135deg,#1a237e,#283593"},
    {l:"Red",    v:"135deg,#b71c1c,#c62828"}, {l:"Teal",   v:"135deg,#004d40,#00695c"},
    {l:"Purple", v:"135deg,#4a148c,#6a1b9a"}, {l:"Blue",   v:"135deg,#0d47a1,#1565c0"},
    {l:"Orange", v:"135deg,#e65100,#bf360c"}, {l:"Forest", v:"135deg,#33691e,#558b2f"},
  ];

  const stats = [
    { icon:"🎬", label:"Total Videos",    val: videos.length },
    { icon:"👁",  label:"Total Views",     val: fmtViews(videos.reduce((s,v)=>s+v.views,0)) },
    { icon:"🏆", label:"Leagues",          val: [...new Set(videos.map(v=>v.league))].length },
    { icon:"🔥", label:"New This Week",    val: videos.filter(v=>v.isNew).length },
  ];

  return (
    <div style={{ background:"var(--bg)", minHeight:"100vh" }}>
      <GlobalStyle />
      {/* Admin header */}
      <div style={{ background:"var(--green-dark)", borderBottom:"2px solid var(--green)", display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 24px", height:56 }}>
        <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:26, color:"var(--gold)", letterSpacing:2 }}>⚽ LACA TV — Admin</div>
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={()=>navigate("home")} style={{ background:"var(--surface2)", color:"var(--muted)", border:"1px solid var(--border)", borderRadius:8, padding:"7px 16px", fontSize:13 }}>← View Site</button>
          <button onClick={()=>{ setAdminAuth(false); navigate("home"); }} style={{ background:"var(--red)", color:"#fff", border:"none", borderRadius:8, padding:"7px 16px", fontSize:13 }}>Logout</button>
        </div>
      </div>

      <div style={{ maxWidth:900, margin:"0 auto", padding:30 }}>
        {/* Stats */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:28 }}>
          {stats.map(s => (
            <div key={s.label} style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:10, padding:16 }}>
              <div style={{ fontSize:22, marginBottom:6 }}>{s.icon}</div>
              <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:28, color:"var(--gold)" }}>{s.val}</div>
              <div style={{ fontSize:12, color:"var(--muted)" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tab switcher */}
        <div style={{ display:"flex", gap:2, marginBottom:24, background:"var(--surface)", borderRadius:10, padding:4, width:"fit-content" }}>
          {[["upload","📤 Upload Video"],["manage","📋 Manage Videos"]].map(([id,label]) => (
            <button key={id} onClick={()=>setTab(id)} style={{ padding:"8px 20px", borderRadius:8, border:"none", background: tab===id?"var(--green-light)":"transparent", color: tab===id?"#fff":"var(--muted)", fontSize:13, fontWeight:500 }}>{label}</button>
          ))}
        </div>

        {/* UPLOAD */}
        {tab==="upload" && (
          <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:14, padding:28 }}>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:22, marginBottom:20, letterSpacing:1 }}>Upload New Highlight</div>
            {msg && (
              <div style={{ padding:"10px 14px", borderRadius:8, marginBottom:18, fontSize:13, background: msg.type==="ok"?"#1a7a3c22":"#e74c3c22", border:`1px solid ${msg.type==="ok"?"var(--green)":"var(--red)"}`, color: msg.type==="ok"?"var(--green-light)":"var(--red)" }}>
                {msg.text}
              </div>
            )}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              <div style={{ gridColumn:"1/-1" }}>
                <label style={lbl}>Video Title *</label>
                <input style={inp} placeholder="e.g. Arsenal 3-1 Chelsea — Premier League Highlights" value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} />
              </div>
              <div>
                <label style={lbl}>League *</label>
                <select style={inp} value={form.league} onChange={e=>setForm(p=>({...p,league:e.target.value}))}>
                  {["Premier League","La Liga","Bundesliga","Serie A","Champions League","NPFL","AFCON","Ligue 1","Europa League","World Cup"].map(l=><option key={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label style={lbl}>Duration (e.g. 8:24)</label>
                <input style={inp} placeholder="8:24" value={form.duration} onChange={e=>setForm(p=>({...p,duration:e.target.value}))} />
              </div>
              <div style={{ gridColumn:"1/-1" }}>
                <label style={lbl}>Video URL * — direct MP4, YouTube embed, or CDN link</label>
                <input style={inp} placeholder="https://..." value={form.videoUrl} onChange={e=>setForm(p=>({...p,videoUrl:e.target.value}))} />
              </div>
              <div style={{ gridColumn:"1/-1" }}>
                <label style={lbl}>Description</label>
                <textarea style={{ ...inp, height:80, resize:"vertical" }} placeholder="Match summary, key moments, goalscorers..." value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} />
              </div>
              <div>
                <label style={lbl}>Tags (comma-separated)</label>
                <input style={inp} placeholder="Arsenal, Chelsea, Premier League" value={form.tags} onChange={e=>setForm(p=>({...p,tags:e.target.value}))} />
              </div>
              <div>
                <label style={lbl}>Thumbnail Colour</label>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginTop:6 }}>
                  {grads.map(g => (
                    <div key={g.v} onClick={()=>setForm(p=>({...p,bgGrad:g.v}))} title={g.l}
                      style={{ width:28, height:28, borderRadius:6, background:`linear-gradient(${g.v})`, cursor:"pointer", border: form.bgGrad===g.v?"2.5px solid var(--gold)":"2.5px solid transparent" }} />
                  ))}
                </div>
              </div>
              <div style={{ gridColumn:"1/-1", display:"flex", gap:24 }}>
                <label style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer", fontSize:13, color:"var(--text)" }}>
                  <input type="checkbox" checked={form.isNew} onChange={e=>setForm(p=>({...p,isNew:e.target.checked}))} /> Mark as NEW
                </label>
                <label style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer", fontSize:13, color:"var(--text)" }}>
                  <input type="checkbox" checked={form.featured} onChange={e=>setForm(p=>({...p,featured:e.target.checked}))} /> Feature on Homepage Hero
                </label>
              </div>
            </div>
            <button onClick={upload} style={{ marginTop:22, background:"var(--green-light)", color:"#fff", border:"none", borderRadius:10, padding:"12px 32px", fontSize:15, fontWeight:600 }}>
              📤 Publish Video
            </button>
          </div>
        )}

        {/* MANAGE */}
        {tab==="manage" && (
          <div>
            <div style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:22, marginBottom:16, letterSpacing:1 }}>All Videos ({videos.length})</div>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {videos.map(v => (
                <div key={v.id} style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:10, padding:"12px 16px", display:"flex", alignItems:"center", gap:14 }}>
                  <div style={{ width:68, height:42, borderRadius:6, background:`linear-gradient(${v.bgGrad})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>⚽</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:13, fontWeight:500, color:"var(--text)", marginBottom:3, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{v.title}</div>
                    <div style={{ fontSize:11, color:"var(--muted)", display:"flex", gap:8, flexWrap:"wrap" }}>
                      <span>{v.league}</span><span>•</span><span>{fmtViews(v.views)} views</span><span>•</span><span>{timeAgo(v.uploadedAt)}</span>
                      {v.isNew     && <span style={{ background:"var(--green-light)", color:"#fff", padding:"1px 6px", borderRadius:4, fontSize:10 }}>NEW</span>}
                      {v.featured  && <span style={{ background:"var(--gold)", color:"var(--green-dark)", padding:"1px 6px", borderRadius:4, fontSize:10 }}>FEATURED</span>}
                    </div>
                  </div>
                  <button onClick={()=>deleteVideo(v.id)} style={{ background:"#e74c3c22", color:"var(--red)", border:"1px solid var(--red)", borderRadius:6, padding:"5px 14px", fontSize:12, flexShrink:0 }}>🗑 Delete</button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────
export default function LacaTV() {
  const [page, setPage]     = useState("home");
  const [video, setVideo]   = useState(null);
  const [videos, setVideos] = useState(MOCK_VIDEOS);
  const [adminAuth, setAdminAuth] = useState(false);

  const navigate = (to, v=null) => { setPage(to); if(v) setVideo(v); window.scrollTo(0,0); };
  const addVideo = v => setVideos(p => [{ ...v, id:Date.now(), views:0, uploadedAt:new Date().toISOString() }, ...p]);
  const deleteVideo = id => setVideos(p => p.filter(v=>v.id!==id));

  return (
    <AppCtx.Provider value={{ videos, addVideo, deleteVideo, navigate, adminAuth, setAdminAuth }}>
      {page==="home"   && <HomePage />}
      {page==="player" && <VideoPlayerPage video={video} />}
      {page==="admin"  && <AdminPage />}
    </AppCtx.Provider>
  );
}
